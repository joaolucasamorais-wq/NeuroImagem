// Static/structural smoke test: does NOT claim browser, DICOM, or deployment validation.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const root = path.resolve(__dirname,'..');
for (const pathInside of ['index.html','wrangler.jsonc','src/main.tsx','dist/index.html','dist/app.js','dist/styles.css','dist/sw.js','dist/manifest.webmanifest','dist/icons/icon-192.png','dist/icons/icon-512.png','dist/vendor/react.production.min.js','dist/vendor/react-dom.production.min.js']){
 assert.ok(fs.existsSync(path.join(root,pathInside)),`Missing: ${pathInside}`);
}
const manifest=JSON.parse(fs.readFileSync(path.join(root,'dist/manifest.webmanifest'),'utf-8'));
assert.equal(manifest.display,'standalone');
assert.equal(manifest.icons.length,2);
const wrangler=fs.readFileSync(path.join(root,'wrangler.jsonc'),'utf-8');
assert.ok(wrangler.includes('single-page-application'));
assert.ok(wrangler.includes('./dist'));
const source=fs.readFileSync(path.join(root,'dist/app.js'),'utf-8');
class Component { constructor(){this.state={}} setState(next){this.state={...this.state,...(typeof next==='function'?next(this.state):next)}} }
let app;
const React={Component,createElement:(tag,props,...children)=>({tag,props,children})};
const ctx=vm.createContext({React,ReactDOM:{render:(el)=>{app=new el.tag(); app.render()}}, document:{getElementById:()=>({})},window:{},navigator:{},localStorage:{},setTimeout:()=>0,clearTimeout:()=>{},console});
vm.runInContext(source,ctx,{timeout:4000});
assert.equal(vm.runInContext('chapterNames.length',ctx),50);
assert.equal(vm.runInContext('axes.length',ctx),10);
assert.equal(vm.runInContext('lessons.length',ctx),5);
assert.equal(vm.runInContext('cases.length',ctx),3);
assert.ok(app && app.renderHome() && app.renderStudy() && app.renderView() && app.renderExplore() && app.renderDiagnose() && app.renderLibrary());
console.log('PASS: 50 chapter titles; 10 axes; 5 introductory lessons; 3 text cases; 6 JSX layouts; PWA files present.');
