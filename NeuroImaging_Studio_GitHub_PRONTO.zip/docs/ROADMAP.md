# Plano de implantação — NeuroImaging Studio

A organização segue o prompt-mestre enviado: **Fases 1–15 no ChatGPT comum; Fases 16–20 no ChatGPT Work**. Nenhuma etapa futura é tratada como concluída.

| Fase | Entrega principal | Status |
|---|---|---|
| 01 | Fundação, identidade, cinco áreas, PWA, persistência, conteúdo inicial | **Implementada no código entregue** |
| 02 | Refinamento VOLUME ROOM, componentes, UI responsiva, upgrade do React | Planejada |
| 03 | Expansão real das 50 aulas, fontes e revisão espaçada | Planejada |
| 04 | Cornerstone3D, importação DICOM, séries, zoom/pan, WW/WL real | Planejada |
| 05 | MPR ortogonal, medidas, anotações e comparação | Planejada |
| 06 | CT Lab | Planejada |
| 07 | MRI Sequence Lab | Planejada |
| 08 | Vascular Imaging Lab | Planejada |
| 09 | Advanced Imaging Lab | Planejada |
| 10 | PlayCanvas Engine integrado, importador GLB | Planejada |
| 11 | Image-to-Anatomy e mapa anatômico | Planejada |
| 12 | Motor completo de casos com progressão | Planejada |
| 13 | Report Studio educacional | Planejada |
| 14 | Biblioteca científica, questões, IA opcional | Planejada |
| 15 | Consolidação, testes e pacote para Work | Planejada |
| 16 | Busca e triagem de bases de exames reais licenciados | Work — planejada |
| 17 | Modelos neuroanatômicos de alta fidelidade revisados | Work — planejada |
| 18 | Integração premium de modelos com PlayCanvas | Work — planejada |
| 19 | Casos multimodais com exames e fontes verificáveis | Work — planejada |
| 20 | Revisão integrada, compatibilidade, liberação final | Work — planejada |

## Princípios que não podem ser flexibilizados

- Dados DICOM são diferentes de ilustrações, PNGs e malhas 3D; manter tipos separados.
- Rotular conteúdo sintético e não renderizar lesões inventadas como se fossem exames reais.
- A fase futura só pode ser declarada concluída com funcionalidade real e teste documentado.
- Não alterar lateralidade, orientação, calibração ou metadados espaciais de exames.
- Sem dados identificáveis de paciente no GitHub, Cloudflare Worker, R2 público ou assets.
- Casos/licenças/referências devem ter rastreabilidade e revisão editorial quando integrados.
