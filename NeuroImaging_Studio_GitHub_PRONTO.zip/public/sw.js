// The pre-cache intentionally includes only the educational application shell, not patient data.
const VERSION = 'volume-room-p1-20261123';
const CACHE = `neuroimaging-${VERSION}`;
const SHELL = ['/', '/index.html', '/manifest.webmanifest', '/styles.css', '/vendor/react.production.min.js', '/vendor/react-dom.production.min.js', '/app.js', '/icons/icon-192.png', '/icons/icon-512.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => Promise.allSettled(SHELL.map(path => cache.add(path)))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('neuroimaging-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(hit => hit || fetch(event.request).then(response => {
    if (response.ok && (event.request.mode === 'navigate' || new URL(event.request.url).pathname.startsWith('/assets/'))) {
      const copy = response.clone(); caches.open(CACHE).then(c => c.put(event.request, copy));
    }
    return response;
  }).catch(() => event.request.mode === 'navigate' ? caches.match('/index.html') : Response.error())));
});

// First-install guarantee for Vite's content-hashed JavaScript and CSS.
self.addEventListener('message', event => {
  if (event.data?.type !== 'PRECACHE_APP_ASSETS' || !Array.isArray(event.data.urls)) return;
  const paths = event.data.urls.filter(value => {
    try { const url = new URL(value); return url.origin === self.location.origin && (/\.(?:js|css)$/.test(url.pathname)); }
    catch { return false; }
  }).slice(0, 30);
  event.waitUntil(caches.open(CACHE).then(cache => Promise.allSettled(paths.map(path => cache.add(path)))));
});
