// Prebuilt bundle check: Cloudflare can deploy without recompiling source in Fase 1.
// Use npm run build:source when you intentionally update the source.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const required = [
  'dist/index.html', 'dist/app.js', 'dist/styles.css',
  'dist/sw.js', 'dist/manifest.webmanifest',
  'dist/vendor/react.production.min.js',
  'dist/vendor/react-dom.production.min.js',
  'dist/icons/icon-192.png', 'dist/icons/icon-512.png'
];
for (const file of required) {
  assert.ok(fs.existsSync(path.join(root, file)), `Arquivo ausente: ${file}`);
  assert.ok(fs.statSync(path.join(root, file)).size > 0, `Arquivo vazio: ${file}`);
}
const html = fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8');
for (const route of ['/app.js','/styles.css','/vendor/react.production.min.js','/vendor/react-dom.production.min.js']) {
  assert.ok(html.includes(route), `Referência ausente: ${route}`);
}
const wrangler = JSON.parse(fs.readFileSync(path.join(root, 'wrangler.jsonc'),'utf8'));
assert.equal(wrangler.assets.directory,'./dist');
assert.equal(wrangler.assets.not_found_handling,'single-page-application');
console.log('OK: pacote compilado e pronto para Cloudflare Workers Static Assets.');
