# Contratos futuros de assets — especificação, não acervo real

A Fase 1 contém apenas diagramas SVG originais, ícones e texto. Este arquivo documenta requisitos **para fases posteriores**; não indica que algum asset DICOM, GLB ou caso visual já exista.

### `medical_study` (futuro)

```json
{
  "id": "study-identifier",
  "modality": "MR",
  "region": "brain",
  "source": "verified-source",
  "license": "license-identifier-and-URL",
  "anonymization_status": "verified",
  "privacy_review": "human-reviewed",
  "pixel_data_location": "private-or-authorized-resource",
  "series": [],
  "spatial_metadata_validated": false,
  "clinical_review": "pending"
}
```

### `anatomy_asset` (futuro)

```json
{
  "id": "anatomy-identifier",
  "structure": "anatomical-terminology",
  "format": "glb",
  "source": "verified-source",
  "license": "license-identifier-and-URL",
  "coordinate_system": "to-be-defined",
  "scale_units": "mm",
  "anatomical_validation": "pending",
  "visual_quality_profile": "clinical"
}
```

### `case` (futuro)

```json
{
  "id": "case-identifier",
  "title": "case-title",
  "study_ids": [],
  "case_type": "synthetic-or-real-anonymized",
  "references": [],
  "expert_review_status": "pending",
  "answers_released_after_response": true
}
```

Não incluir registros que afirmem validação já realizada quando ainda pendente.
